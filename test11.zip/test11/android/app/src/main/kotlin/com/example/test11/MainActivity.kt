package com.example.test11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
