import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:test11/Screens/Screen1.dart';
import 'package:test11/Screens/Screen2.dart';
import 'package:test11/Screens/Screen3.dart';

class wrapper extends StatelessWidget {

  _getScreen() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString('role') == null )
      return Screen1();
    else if (prefs.getString('role') == '2')
      return Screen2();
    else if(prefs.getString('role') == '3')
      return Screen3();
  }


  @override
  Widget build(BuildContext context) {
    //TODO : ADD STREAM HERE
    return Container();
  }
}