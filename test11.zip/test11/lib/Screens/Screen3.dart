import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Screen3 extends StatelessWidget {
  onTap() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('role', null);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              Text('Screen 3',style: TextStyle(fontSize: 30),),
              FlatButton(
                child: Text('Screen 1'),
                onPressed: onTap,
              )
            ],
          ),
        ),
      ),
    );
  }
}
