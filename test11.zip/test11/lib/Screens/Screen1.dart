import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Screen1 extends StatelessWidget {
  onTap() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('role', '2');
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              Text('Screen 1',style: TextStyle(fontSize: 30)),
              FlatButton(
                child: Text('Screen 2'),
                onPressed: onTap,
              )
            ],
          ),
        ),
      ),
    );
  }
}

