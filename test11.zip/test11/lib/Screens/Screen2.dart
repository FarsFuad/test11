import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Screen2 extends StatelessWidget {
  onTap() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('role', '3');
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              Text('Screen 2',style: TextStyle(fontSize: 30)),
              FlatButton(
                child: Text('Screen 3'),
                onPressed: onTap,
              )
            ],
          ),
        ),
      ),
    );
  }
}
